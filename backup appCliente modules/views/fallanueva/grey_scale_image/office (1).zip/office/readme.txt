This folder contains a few pointclouds of my office at TU Munich captured with the
Kinect sensor.

Julius Kammerl - julius@kammerl.de 

# NOTA2: Los ids de los dispositivos del kinect son:
#			- ID 045e:02ae Microsoft Corp. Xbox NUI Camera
#			- ID 045e:02b0 Microsoft Corp. Xbox NUI Motor
#			- ID 045e:02ad Microsoft Corp. Xbox NUI Audio
#			- ID 0409:005a NEC Corp. HighSpeed Hub

ID_USB_CAMERA = "045e:02ae"
ID_USB_MOTOR = "045e:02b0"
ID_USB_AUDIO = "045e:02ad"
ID_USB_HUB = "0409:005a"



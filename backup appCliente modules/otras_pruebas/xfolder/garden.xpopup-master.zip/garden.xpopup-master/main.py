import kivy
kivy.require('1.9.1')
from kivy.base import runTouchApp

__author__ = 'ophermit'

from demo_app import XPopupDemo
runTouchApp(XPopupDemo())
